// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'blog_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$blogRepositoryHash() => r'908b400b26dc8a6f4705fb12c3cb48676f9096ba';

/// See also [blogRepository].
@ProviderFor(blogRepository)
final blogRepositoryProvider = AutoDisposeProvider<BlogRepository>.internal(
  blogRepository,
  name: r'blogRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$blogRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef BlogRepositoryRef = AutoDisposeProviderRef<BlogRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
