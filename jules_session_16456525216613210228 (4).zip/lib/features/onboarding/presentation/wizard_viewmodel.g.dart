// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wizard_viewmodel.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$wizardViewModelHash() => r'95bde21bdf0730ec8a3a4c000f7aa9d8fa2520fd';

/// See also [WizardViewModel].
@ProviderFor(WizardViewModel)
final wizardViewModelProvider =
    AutoDisposeNotifierProvider<WizardViewModel, WizardState>.internal(
      WizardViewModel.new,
      name: r'wizardViewModelProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$wizardViewModelHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$WizardViewModel = AutoDisposeNotifier<WizardState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
