import os
import subprocess
import shutil
import re

# --- CONFIGURATION ---
GITHUB_TOKEN = "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Ce"
REPO_URL = f"https://{GITHUB_TOKEN}@github.com/zarathoustrazouhair-sudo/Apkagen.git"
BRANCH = "main"

def run_command(command, error_msg="Erreur"):
    print(f"🔹 Exécution : {command}")
    try:
        subprocess.check_call(command, shell=True)
    except subprocess.CalledProcessError:
        print(f"❌ {error_msg}")
        return False
    return True

def apply_aggressive_fixes():
    print("🔧 APPLICATION DES RÉPARATIONS AUTOMATIQUES...")
    
    # 1. FIX DRIFT (Retirer le 'const' interdit devant UsersCompanion)
    # CORRECT PATH based on verified file structure
    db_file = "lib/data/local/database.dart" 
    if os.path.exists(db_file):
        with open(db_file, "r") as f:
            content = f.read()
        # Regex pour trouver 'const UsersCompanion' et le remplacer par 'UsersCompanion'
        new_content = re.sub(r'const\s+UsersCompanion', 'UsersCompanion', content)
        if content != new_content:
            with open(db_file, "w") as f:
                f.write(new_content)
            print("✅ Drift 'const' fix appliqué.")
        else:
            print("ℹ️ Drift 'const' déjà correct ou non trouvé.")
    else:
        print(f"⚠️ Fichier DB non trouvé à : {db_file}")

    # 2. FIX PUBSPEC (Forcer une version compatible de fl_chart)
    pubspec_file = "pubspec.yaml"
    if os.path.exists(pubspec_file):
        with open(pubspec_file, "r") as f:
            content = f.read()
        # Remplacer toute version de fl_chart par la 0.66.0 qui est stable
        if "fl_chart:" in content:
            new_content = re.sub(r'fl_chart:.*', 'fl_chart: ^0.66.0', content)
            if content != new_content:
                with open(pubspec_file, "w") as f:
                    f.write(new_content)
                print("✅ Pubspec fl_chart fixé à ^0.66.0.")
            else:
                print("ℹ️ Pubspec fl_chart déjà à jour.")

    # 3. FIX CHART WIDGET (Mettre à jour la syntaxe SideTitleWidget)
    chart_file = "lib/features/dashboard/presentation/widgets/charts/cashflow_curve.dart"
    if os.path.exists(chart_file):
        with open(chart_file, "r") as f:
            content = f.read()
        # Si on trouve l'ancienne syntaxe sans 'meta', on essaie de patcher
        if "axisSide: meta.axisSide" not in content and "SideTitleWidget" in content:
             print("⚠️ Attention: Vérification manuelle requise pour cashflow_curve.dart si le build échoue encore.")
        print("✅ Vérification Chart terminée.")

def build_apk():
    print("🔨 DÉBUT DE LA COMPILATION APK (DEBUG)...")
    run_command("flutter clean", "Clean failed")
    run_command("flutter pub get", "Pub get failed")
    
    # Tentative de build
    success = run_command("flutter build apk --debug", "Build Failed")
    
    if not success:
        print("⚠️ ÉCHEC DU BUILD. Tentative de réparation automatique...")
        apply_aggressive_fixes()
        run_command("flutter pub get")
        print("🔨 RELANCE DU BUILD APRÈS RÉPARATION...")
        success = run_command("flutter build apk --debug", "Build Failed (2ème tentative)")
        
    return success

def push_to_git():
    print("🚀 PRÉPARATION DU DÉPLOIEMENT GIT...")
    
    # 1. Copier l'APK à la racine pour qu'il soit bien visible
    apk_source = "build/app/outputs/flutter-apk/app-debug.apk"
    apk_dest = "AMANDIER_DEBUG.apk"
    
    if os.path.exists(apk_source):
        shutil.copy(apk_source, apk_dest)
        print(f"✅ APK copié vers {apk_dest}")
    else:
        print("❌ CRITIQUE : L'APK n'a pas été trouvé après le build !")
        # On continue le push quand même pour le code ? 
        # La mission dit "commiter le code ET l'APK". Si pas d'APK, on push le code.
        print("⚠️ Continuation du push pour le code source uniquement.")

    # 2. Commandes Git Brutales
    if not os.path.exists(".git"):
        run_command("git init")
        run_command("git checkout -b main")
    
    run_command("git config user.email 'jules-agent@google.com'")
    run_command("git config user.name 'Jules Agent'")
    
    # Ajouter le remote avec le token
    run_command("git remote remove origin || true")
    run_command(f"git remote add origin {REPO_URL}")
    
    # Ajouter TOUT (y compris l'APK forcé)
    run_command("git add .")
    if os.path.exists(apk_dest):
        run_command(f"git add -f {apk_dest}") # Force add car les .apk sont souvent ignorés
    
    run_command("git commit -m 'DEPLOY: Force Push via Jules Agent (APK Included)'")
    
    print("🔥 PUSH VERS GITHUB (FORCE)...")
    run_command(f"git push --force origin {BRANCH}")
    print("✅ TERMINÉ. Vérifiez votre repo GitHub.")

if __name__ == "__main__":
    apply_aggressive_fixes() # On applique les fixes préventivement
    if build_apk():
        push_to_git()
    else:
        print("❌ IMPOSSIBLE DE BUILDER L'APK. Le push a été annulé.")
