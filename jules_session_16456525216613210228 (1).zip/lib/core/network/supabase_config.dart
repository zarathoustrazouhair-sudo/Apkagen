class SupabaseConfig {
  static const String url = 'https://kxvgkjkjlswpmgqwiuft.supabase.co';
  static const String publicKey = 'sb_publishable_SohSJcEYjSQJcynzRbPWsA_91Ep_8M5';
}
