package com.example.residence_lamandier_b

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
